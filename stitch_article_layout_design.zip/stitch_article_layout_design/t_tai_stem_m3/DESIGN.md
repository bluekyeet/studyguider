---
name: Tātai STEM M3
colors:
  surface: '#fbf8ff'
  surface-dim: '#dad9e3'
  surface-bright: '#fbf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f4f2fd'
  surface-container: '#eeedf7'
  surface-container-high: '#e8e7f1'
  surface-container-highest: '#e3e1ec'
  on-surface: '#1a1b22'
  on-surface-variant: '#444651'
  inverse-surface: '#2f3038'
  inverse-on-surface: '#f1effa'
  outline: '#757682'
  outline-variant: '#c5c5d3'
  surface-tint: '#4059aa'
  primary: '#00236f'
  on-primary: '#ffffff'
  primary-container: '#1e3a8a'
  on-primary-container: '#90a8ff'
  inverse-primary: '#b6c4ff'
  secondary: '#006a61'
  on-secondary: '#ffffff'
  secondary-container: '#86f2e4'
  on-secondary-container: '#006f66'
  tertiary: '#442100'
  on-tertiary: '#ffffff'
  tertiary-container: '#653400'
  on-tertiary-container: '#fc922b'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dce1ff'
  primary-fixed-dim: '#b6c4ff'
  on-primary-fixed: '#00164e'
  on-primary-fixed-variant: '#264191'
  secondary-fixed: '#89f5e7'
  secondary-fixed-dim: '#6bd8cb'
  on-secondary-fixed: '#00201d'
  on-secondary-fixed-variant: '#005049'
  tertiary-fixed: '#ffdcc3'
  tertiary-fixed-dim: '#ffb77d'
  on-tertiary-fixed: '#2f1500'
  on-tertiary-fixed-variant: '#6e3900'
  background: '#fbf8ff'
  on-background: '#1a1b22'
  surface-variant: '#e3e1ec'
  ncea-achieved: '#059669'
  ncea-merit: '#2563EB'
  ncea-excellence: '#7C3AED'
  review-amber: '#D97706'
  formula-bg: '#F1F5F9'
  surface-tonal-container: '#F8FAFC'
  chem-bond: '#0F766E'
typography:
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 32px
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 30px
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 26px
  title-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  title-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 22px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 16px
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '500'
    lineHeight: 14px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-tablet: 1.5rem
  margin: 1rem
  margin-tablet: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.25rem
---

## Brand & Style

This design system establishes a high-clarity, distraction-free native Android study ecosystem for New Zealand secondary students preparing for NCEA Level 2 and Level 3 STEM standards (Physics, Chemistry, Calculus, and Statistics). It rejects frivolous gamification, cartoonish rewards, and high-noise dopamine loops in favor of deep focus, academic legitimacy, and verified mastery.

The visual direction merges **Material 3 (M3) Native Android paradigms** with a disciplined, editorial rigor inspired by university publishing and scientific notebooks. Key personality traits:
- **Authoritative & Grounded:** Evokes confidence through deep academic indigo and teal accents, honoring the official structure of the New Zealand Qualifications Authority (NZQA).
- **Cognitively Quiet:** Vast neutral planes, warm low-glare surface tints, and deliberate typographic rhythm that make complex algebraic proofs and multi-step chemical reaction mechanisms effortless to parse on handheld devices.
- **Evidence-First:** Every explanation, calculation, and grade is explicitly anchored to source citations, mark schedules, and verified criteria.
- **Ergonomic Mobility:** Optimized for high-frequency one-handed mobile use in study halls, buses, and library desks, with bottom-sheet interactions, thumb-accessible toolbars for mathematical entry, and clear visual hierarchy for KaTeX formula blocks.

## Colors

The color palette translates the Material 3 tonal system into an educational environment built for extended reading sessions under varied lighting conditions.

- **Primary (`#1E3A8A` - Deep Academic Indigo):** Anchor color for top app bars, primary action buttons, key active tabs, and primary navigation states. Communicates institutional authority, focus, and intellectual stability.
- **Secondary (`#0D9488` - Deep Teal):** Interactive accents, secondary callouts, formula highlighting, interactive inline `Explain in detail` triggers, and active chemical compound references.
- **Tertiary (`#D97706` - Warm Amber):** Alert states, revision reminders, upcoming exam deadlines, and warnings for content flagged as "General Knowledge" rather than sourced directly from verified NCEA exemplars.
- **Neutral (`#71717A` - Slate Neutral):** Provides balanced slate grays that prevent glare during long screen time, with dedicated tonal surface layers (`#F8FAFC` to `#E2E8F0`).

### NCEA Mastery Indicators
To mirror the official NZQA assessment hierarchy without introducing visual chaos, a distinct triad of mastery colors is codified:
- **Achieved (`#059669` - Emerald):** Clear positive validation indicating foundational competency met.
- **Merit (`#2563EB` - Royal Cobalt):** Deeper precision indicating advanced relational comprehension.
- **Excellence (`#7C3AED` - Deep Amethyst):** Distinguished tone reserved for extended abstract synthesis and full exam rigor.

### Scientific Notation & Formula Displays
All KaTeX blocks, chemical equations (`mhchem`), and mathematical derivation containers utilize an elevated background of `#F1F5F9` paired with an inner border of `#CBD5E1` to visually separate formal notation from continuous narrative prose.

## Typography

The typographic hierarchy coordinates three complementary families tailored for scientific rigor and digital legibility:

1. **Display & Section Headers (`Space Grotesk`):** Modern, geometric, with subtle technical cues that elevate standard learning unit titles, NCEA standard IDs (e.g., *AS91524 3.4 Mechanical Systems*), and performance metrics without feeling overly industrial.
2. **Reading & Explanations (`Inter`):** Engineered for dense cross-device reading. Tall x-height and neutral geometry ensure extended worked solutions, mark schedules, and conceptual chunk explanations remain fatigue-free.
3. **Labels, Code, & Formula References (`JetBrains Mono`):** Dedicated to technical metadata, mark distribution (e.g., `[4 MARKS]`), inline formula triggers, standard classification codes, and raw LaTeX parameter editing.

### KaTeX & Chemical Formula Integration
- **Inline Formulas (`$...$`):** Match `Inter` body sizing identically (14px–16px baseline aligned), dynamically rendered to preserve natural line pacing without vertical clipping or overlapping ascenders/descenders.
- **Display Formulas (`$$...$$`):** Rendered in centered, horizontally scrollable containers with a minimum vertical line padding of `8px` above and below, preventing multi-line fraction or integral collision.

## Layout & Spacing

Layout geometry follows an 8dp native Android base rhythm with a 4dp sub-grid for fine-grained alignments (such as formula symbols, chip tags, and status dots).

### Layout Geometry
- **Mobile Handheld (360dp - 599dp):** Single-column vertical stream. 16dp outer screen margin (`margin`), 16dp component gutter (`gutter`). Touch targets adhere strictly to a 48dp minimum hit zone. Bottom navigation bars and contextual math toolbars sit anchored within the primary thumb reach zone.
- **Tablet / Split-Screen (600dp - 900dp+):** Dual-pane structure. Question OCR scan or official marking schedule anchors the left pane (50% or 45% flex), while student working, step-by-step KaTeX breakdown, and AI evidence-checking span the right pane. Margins expand to 32dp (`margin-tablet`) with 24dp inner gutters (`gutter-tablet`).

### Lesson Chunking Cadence
In the Lesson Reader, each sequential pedagogical chunk (*Learning Goal*, *Prior Knowledge*, *Concept*, *Worked Example*, *Your Turn*, *Common Mistakes*) is visually demarcated with `space-lg` (24dp) bottom margins and `space-md` internal card padding, guaranteeing atomic readability.

## Elevation & Depth

This design system implements **Material 3 Tonal Elevation**, replacing sharp, artificial drop shadows with surface tint shifts mixed directly into the base neutral background.

- **Level 0 (Surface Base - `#FFFFFF`):** The canvas baseline for full-screen lesson reading and scrollable exam papers.
- **Level 1 (Surface Container Low - `#F8FAFC`):** Non-interactive chunk backgrounds, worked solution cards, and citation reference blocks. Depth is defined solely by a subtle `1px` stroke of `#E2E8F0`.
- **Level 2 (Surface Container - `#F1F5F9`):** Interactive lesson cards, input text containers, and math preview bars. Ambient soft shadow: `0px 2px 6px rgba(15, 23, 42, 0.04)`.
- **Level 3 (Surface Container High - `#E2E8F0`):** Floating toolbars (e.g., KaTeX formula keyboard helper), active selection pills, and draggable bottom-sheet headers. Ambient soft shadow: `0px 4px 12px rgba(15, 23, 42, 0.08)`.
- **Level 4 (Modal & Overlays - `#FFFFFF`):** `Explain in detail` bottom-sheet panels and LaTeX equation builders. Layered over a `rgba(15, 23, 42, 0.4)` scrim with an elevation shadow of `0px 8px 24px rgba(15, 23, 42, 0.12)`.

## Shapes

The design system adopts a balanced **Rounded (`roundedness: 2`)** aesthetic, honoring modern Android Material 3 form factors while ensuring scientific figures, mathematical coordinate plots, and dense exam schedules retain structural clarity.

- **Standard Cards & Containers:** `0.75rem` (12dp) to `1rem` (16dp) corner radius, framing content with friendly yet orderly boundaries.
- **Math Formula & Code Blocks:** `0.5rem` (8dp) corner radius, signaling technical compartmentalization.
- **Buttons & Status Chips:** `1.5rem` (24dp pill radius) for single-action status markers, NCEA mastery tags, and floating action triggers.
- **Bottom Sheets & Modal Surfaces:** `1.5rem` (24dp) rounded top corners for fluid slide-up interactions.

## Components

### Buttons
- **Filled Primary:** `#1E3A8A` background with crisp white typography and a pill shape (`24dp`). Used for primary lesson advancement, exam submission, and final grade overrides.
- **Tonal Secondary:** `#E0F2FE` background with `#0369A1` text. Used for "Next Step" or "Check Working".
- **Inline Formula Action (`Explain in detail`):** Subtle inline chip button attached to formulas and paragraphs. Outlined with `#CBD5E1`, `#0D9488` text, an icon depicting an analytical spark/magnifier, and a compact 28dp height.

### Status & Mastery Chips
- Compact `24dp` height with `JetBrains Mono` 11px uppercase typography.
- **Achieved:** Emerald tint background (`#ECFDF5`), `#065F46` label, small 6dp filled emerald dot.
- **Merit:** Cobalt tint background (`#EFF6FF`), `#1E40AF` label, 6dp filled cobalt dot.
- **Excellence:** Amethyst tint background (`#F5F3FF`), `#5B21B6` label, 6dp filled violet star/dot.
- **Review Alert:** Amber tint background (`#FFFBEB`), `#92400E` label.

### KaTeX & Chemical Formula Containers
- Enclosed in `#F1F5F9` background, `8dp` radius, and a crisp `1px` border of `#E2E8F0`.
- Includes an integrated right-aligned quick-action toolbar containing "Copy LaTeX" and "Explain Step".
- Formulas scroll horizontally on overflow without truncating mathematical operators or chemical arrows (`->`, `<=>`).

### Maths Input Helper & Specialized Toolbar
- Anchored directly above the soft keyboard during formula entry.
- Horizontal carousel featuring quick-tap mathematical symbols: `\frac{}{}`, `x^n`, `\sqrt{}`, `\int`, `\sum`, `\Delta`, `\theta`, and common `\ce{...}` chemical symbols.
- Features real-time split preview rendering: top half displays live KaTeX compilation, bottom half displays raw LaTeX token string.

### Lesson Reader & Step-by-Step Chunks
- Structured vertical stream with clear visual tags:
  1. *Learning Goal:* Bordered with a solid 3dp primary accent strip on the left margin.
  2. *Worked Example:* Dual-tone card containing question prompt followed by step-by-step annotated algebraic working.
  3. *Your Turn:* Interactive card containing an embedded formula input helper and instant submission check.
- Real-time streaming indicator: When AI explanations stream via SSE, text flows with a smooth low-opacity fading cursor dot in `#0D9488`.

### Side-by-Side Verification (Exam Paper Check)
- Implemented as a resizable two-column split view for tablets and large foldables.
- Left view displays the source scan crop with zoom and pan affordance.
- Right view displays the parsed standard metadata, question parts, mark breakdown, and editable manual override inputs with required rationale notes.